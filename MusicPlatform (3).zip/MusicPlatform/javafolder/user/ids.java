package user;
/**
 * Enumeration representing different user IDs.
 * Each ID corresponds to a specific user.
 */
public enum ids {
	
	    ID_1,
	    ID_2,
	    ID_3,
	    ID_4,
	    ID_5,
	
}
