package metadata;
import java.util.*;
import defaultpck.*;
import metadatagroup.*;
import user.*;
public class media {
    public String mediatype;
    public int rating;
    public String owner;
}
